// plugins/tagall.js
let handler = async (m, { conn, isAdmin, isOwner, isROwner }) => {
    if (!m.isGroup) return;
    if (!isAdmin && !isOwner && !isROwner) {
        global.dfail('admin', m, conn);
        return;
    }

    let groupData = conn.chats?.[m.chat];
    if (!groupData?.metadata?.participants) return m.reply('لا يمكن الوصول لبيانات المجموعة');

    let participants = groupData.metadata.participants;
    let mentions = participants.map(p => p.id);
    let tags = participants.map(p => '@' + p.id.split('@')[0]).join('\n');

    let text = `*👥 منشن جميع الأعضاء*\n\n${tags}`;
    let imageUrl = 'https://i.ibb.co/7d7bs5bM/IMG-20260827-WA0193.jpg';

    await conn.sendMessage(m.chat, { image: { url: imageUrl }, caption: text, mentions });
};

handler.command = /^منشن$/i;
handler.group = true;
handler.admin = true;

export default handler;