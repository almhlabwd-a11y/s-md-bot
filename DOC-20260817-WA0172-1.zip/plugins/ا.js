// plugins/nixcode-demo.js
// ✧ 2B - YoRHa Unit No.2 Type B - عرض جميع أنواع الأزرار 🔘

import { Button, ButtonV2, Carousel } from '../core/NIXCODE.js'

let handler = async (m, { conn }) => {

  // ═══════════════════════════════════════
  // 1️⃣ زر عادي + قائمة منسدلة + URL + Copy
  // ═══════════════════════════════════════
  await new Button(conn)
    .setTitle('❄️ 2B - YoRHa Unit')
    .setSubtitle('الأزرار التفاعلية')
    .setBody('اختر من القائمة أدناه')
    .setFooter('❄️ 2B - YoRHa Unit No.2 Type B ❄️')
    .setImage('https://file.garden/aauvg01sjleV_ic1/2B.jpg')
    .addReply('📂 الأقسام', '.اوامر')
    .addReply('👤 المطور', '.المطور')
    .addUrl('📢 القناة', 'https://whatsapp.com/channel/0029Vb8We2VKrWR2Z9E5KQ1P', true)
    .addCopy('📋 نسخ الرقم', '966504653864')
    .addSelection('📚 اختر القسم')
    .makeSection('الأقسام الرئيسية')
    .makeRow('👮‍♂️', 'قسم الأدمن', 'أوامر المشرفين', '.ق1')
    .makeRow('🎨', 'قسم الاستيكر', 'الملصقات', '.ق2')
    .makeRow('🎮', 'قسم الألعاب', 'ألعاب تفاعلية', '.ق3')
    .send(m.chat, { quoted: m })

  // ═══════════════════════════════════════
  // 2️⃣ أزرار عائمة (Floating)
  // ═══════════════════════════════════════
  await new ButtonV2(conn)
    .setTitle('❄️ 2B - YoRHa Unit')
    .setSubtitle('أزرار عائمة')
    .setBody('هذه أزرار منفصلة عن النص')
    .setFooter('❄️ 2B - YoRHa Unit No.2 Type B ❄️')
    .setThumbnail('https://file.garden/aauvg01sjleV_ic1/2B.jpg')
    .addRawButton({
      buttonText: { displayText: '📂 الأقسام' },
      buttonId: 'menu',
      type: 1,
      nativeFlowInfo: {
        name: 'single_select',
        paramsJson: JSON.stringify({
          title: "اختر القسم",
          sections: [{
            title: "الأقسام",
            rows: [
              { title: "👮‍♂️ قسم الأدمن", description: "أوامر المشرفين", id: ".ق1" },
              { title: "🎨 قسم الاستيكر", description: "الملصقات", id: ".ق2" },
              { title: "🎮 قسم الألعاب", description: "ألعاب تفاعلية", id: ".ق3" }
            ]
          }]
        })
      }
    })
    .addButton('👤 المطور', '.المطور')
    .addButton('⭐ تقييم', '.تقييم')
    .send(m.chat)

  // ═══════════════════════════════════════
  // 3️⃣ كاروسيل (سلايدر)
  // ═══════════════════════════════════════
  await new Carousel(conn)
    .setBody('🎮 أقسام 2B')
    .setFooter('❄️ اسحب للتصفح ❄️')
    .addCard(
      await new Button(conn)
        .setTitle('👮‍♂️ قسم الأدمن')
        .setBody('أوامر المشرفين')
        .setImage('https://file.garden/aauvg01sjleV_ic1/download%20(5).jpg')
        .addReply('📂 فتح', '.ق1')
        .toCard()
    )
    .addCard(
      await new Button(conn)
        .setTitle('🎮 قسم الألعاب')
        .setBody('ألعاب تفاعلية')
        .setImage('https://file.garden/aauvg01sjleV_ic1/Fabio%20Ferrero%20(@funzionefabio)%20%E2%80%A2%20Instagram%20photos%20and%20videos.jpg')
        .addReply('🎮 فتح', '.ق3')
        .toCard()
    )
    .addCard(
      await new Button(conn)
        .setTitle('🎉 قسم التسلية')
        .setBody('ترفيه وألعاب')
        .setImage('https://file.garden/aauvg01sjleV_ic1/2B.webp')
        .addReply('🎉 فتح', '.ق10')
        .toCard()
    )
    .send(m.chat, { quoted: m })

}

handler.help = ['نيوكس']
handler.tags = ['tools']
handler.command = /^(نيوكس|nixcode|demo)$/i

export default handler