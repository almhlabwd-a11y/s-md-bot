// plugins/owner.js
// ✧ 2B - YoRHa Unit No.2 Type B - المطور

import { theme } from '../core/theme.js'

let handler = async (m, { conn }) => {
  try {
    await conn.sendMessage(
      m.chat,
      {
        audio: { url: 'https://file.garden/aauvg01sjleV_ic1/pro.opus' },
        mimetype: 'audio/mp4',
        ptt: true 
      },
      { quoted: m }
    );
    await new Promise(resolve => setTimeout(resolve, 1000));
  } catch (e) {}

  let vcard = `BEGIN:VCARD
VERSION:3.0
FN:✧ 𝟐𝐁 - YoRHa Unit No.2 Type B ✧
ORG:YoRHa
TITLE:2B - YoRHa Unit
EMAIL;type=INTERNET:go588288@gmail.com
TEL;type=CELL;waid=966504653864:+966504653864
ADR;type=WORK:;;Bunker;YoRHa;;
URL;type=WORK:https://www.instagram.com/go24.q?igsh=MWdoYWtjZWNnMGhncQ==
X-WA-BIZ-NAME:✧ 𝟐𝐁 - YoRHa Unit ✧
X-WA-BIZ-DESCRIPTION:❄️ YoRHa Unit No.2 Type B - 𝘐'𝘮 𝘯𝘰𝘵 𝘩𝘶𝘮𝘢𝘯 𝘢𝘯𝘺𝘮𝘰𝘳𝘦
X-WA-BIZ-HOURS:Mo-Su 00:00-23:59
END:VCARD`

  let qkontak = {
    key: {
      fromMe: false,
      participant: "0@s.whatsapp.net",
      remoteJid: "status@broadcast"
    },
    message: {
      contactMessage: {
        displayName: "✧ 𝟐𝐁 - YoRHa Unit ✧",
        vcard
      }
    }
  }

  await conn.sendMessage(
    m.chat,
    {
      contacts: {
        displayName: '✧ 𝟐𝐁 - YoRHa Unit No.2 Type B ✧',
        contacts: [{ vcard }]
      }
    },
    { quoted: qkontak }
  )
}

handler.help = ['owner', 'creator']
handler.tags = ['main']
handler.command = /^(owner|creator|المطورين|المطور|مطور|مطورك|مطوري|creador)$/i

export default handler