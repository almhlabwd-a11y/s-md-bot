// plugins/mute.js
// ✧ 2B - YoRHa Unit No.2 Type B - كتم أو فك كتم عضو 🔇

let handler = async (m, { conn, command, isAdmin }) => {
    if (!m.isGroup) return;
    if (!isAdmin) {
        return m.reply('> ❄️ *2B: "صلاحيات غير كافية"*\n> \n> ⚠️ فقط المشرفين يمكنهم تنفيذ هذا الأمر');
    }

    let targetJid = m.mentionedJid?.[0] || m.quoted?.sender;

    if (!targetJid) {
        await conn.sendMessage(m.chat, { react: { text: '⚠️', key: m.key } });
        return m.reply(`> ❄️ *2B: "${command === 'كتم' ? 'أمر الكتم' : 'أمر فك الكتم'}"*\n> \n> ⚠️ قم بالرد على رسالة العضو أو منشنه\n> 📌 *للكتم:* رد على رسالة العضو ثم اكتب .كتم\n> 📌 *لفك الكتم:* رد على رسالة العضو ثم اكتب .فك_الكتم`);
    }

    if (targetJid === conn.user.jid || targetJid === conn.user.lid) {
        return m.reply('> ❄️ *2B: "ممنوع"*\n> \n> ❌ لا يمكنك تنفيذ الأمر على البوت');
    }

    const ownerNumbers = global.owner.map(n => n.replace(/[^0-9]/g, ''));
    let targetNum = targetJid.replace(/[^0-9]/g, '');
    if (ownerNumbers.includes(targetNum)) {
        return m.reply('> ❄️ *2B: "ممنوع"*\n> \n> 👑 لا يمكن تنفيذ الأمر على قائد الوحدة');
    }

    // 🆕 جلب كل المعرّفات (LID + رقم الهاتف) لنفس الشخص
    let allIds = [targetJid];
    try {
        const groupMetadata = await conn.groupMetadata(m.chat);
        const groupOwner = groupMetadata.owner || '';
        if (targetJid === groupOwner || targetNum === groupOwner.replace(/[^0-9]/g, '')) {
            return m.reply('> ❄️ *2B: "ممنوع"*\n> \n> ❌ لا يمكنك تنفيذ الأمر على مالك المجموعة');
        }

        const participant = groupMetadata.participants.find(p =>
            p.id === targetJid ||
            (p.phoneNumber || '').replace(/[^0-9]/g, '') === targetNum
        );
        if (participant) {
            if (participant.id) allIds.push(participant.id);
            if (participant.phoneNumber) allIds.push(participant.phoneNumber);
        }
    } catch (e) {}

    allIds = [...new Set(allIds)]; // إزالة التكرار

    if (!global.db.data.users) global.db.data.users = {};

    // الحصول على الاسم
    let targetName = targetJid.split('@')[0];
    try {
        const name = await conn.getName(targetJid);
        if (name && !name.match(/^\d+$/)) targetName = name;
    } catch (e) {}

    if (command === "كتم") {
        const alreadyMuted = allIds.some(id => global.db.data.users[id]?.muto === true);
        if (alreadyMuted) {
            return m.reply('> ❄️ *2B: "تنبيه"*\n> \n> ⚠️ هذا العضو مكتوم بالفعل');
        }
        // 🆕 كتم كل المعرّفات المرتبطة بنفس الشخص
        for (const id of allIds) {
            if (!global.db.data.users[id]) global.db.data.users[id] = {};
            global.db.data.users[id].muto = true;
        }
        await conn.sendMessage(m.chat, { react: { text: '🔇', key: m.key } });
        await conn.sendMessage(m.chat, {
            text: `> ❄️ *2B: "تم كتم العضو"*\n> \n> 👤 *العضو:* @${targetJid.split('@')[0]}\n> 🔇 تم كتم العضو بنجاح`,
            mentions: [targetJid]
        }, { quoted: m });
    }
    else if (command === "فك_الكتم") {
        const isMuted = allIds.some(id => global.db.data.users[id]?.muto === true);
        if (!isMuted) {
            return m.reply('> ❄️ *2B: "تنبيه"*\n> \n> ⚠️ هذا العضو غير مكتوم');
        }
        // 🆕 فك الكتم عن كل المعرّفات المرتبطة بنفس الشخص
        for (const id of allIds) {
            if (!global.db.data.users[id]) global.db.data.users[id] = {};
            global.db.data.users[id].muto = false;
        }
        await conn.sendMessage(m.chat, { react: { text: '🔊', key: m.key } });
        await conn.sendMessage(m.chat, {
            text: `> ❄️ *2B: "تم فك كتم العضو"*\n> \n> 👤 *العضو:* @${targetJid.split('@')[0]}\n> 🔊 تم فك كتم العضو بنجاح`,
            mentions: [targetJid]
        }, { quoted: m });
    }
};

handler.all = async function (m) {
    if (!m.isGroup || !global.db.data.users) return;
    if (!global.db.data.users[m.sender]) return;

    let user = global.db.data.users[m.sender];
    if (!user.muto) return;

    try {
        const groupMetadata = await this.groupMetadata(m.chat);
        const admins = groupMetadata.participants.filter(p => p.admin).map(p => p.id);
        if (admins.includes(m.sender)) return;
    } catch (e) {}

    await this.sendMessage(m.chat, {
        delete: {
            remoteJid: m.chat,
            fromMe: false,
            id: m.key.id,
            participant: m.sender
        }
    }).catch(() => {});
};

handler.help = ['كتم', 'فك_الكتم'];
handler.command = /^(كتم|فك_الكتم)$/i;
handler.group = true;
handler.admin = true;
handler.botAdmin = true;

export default handler;