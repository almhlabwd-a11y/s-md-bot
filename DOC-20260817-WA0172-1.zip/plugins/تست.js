// plugins/anime-edit.js
import axios from 'axios';
import { theme } from '../core/theme.js';

const API_URL = 'https://2b.hidenfree.com';

const SEARCH_KEYWORDS = [
    'gabimaru edit',
    'gabimaru anime edit',
    'gabimaru hells paradise edit',
    'gabimaru jigokuraku edit',
    'gabimaru 8k edit',
    'gabimaru 4k edit'
];

const CHANNELS = [
    { jid: '120363410623489202@newsletter', name: 'Raiden ShogunXcodes' },
    { jid: '120363410623489202@newsletter', name: 'Raiden Shogun╳ 𝗕𝗢𝗧𝗦 •' }
];

let handler = async (m, { conn, text }) => {

    await conn.sendMessage(m.chat, { react: { text: '🎬', key: m.key } });

    const randomChannel = CHANNELS[Math.floor(Math.random() * CHANNELS.length)];
    let searchQuery = SEARCH_KEYWORDS[Math.floor(Math.random() * SEARCH_KEYWORDS.length)];

    try {
        // ✅ بحث عن فيديوهات غابيمارو
        const { data } = await axios.get(`${API_URL}/api/pinterest/search`, {
            params: {
                q: searchQuery,
                type: 'video',
                limit: 5,
                quality: '8k'
            },
            timeout: 30000,
            validateStatus: () => true
        });

        const videos = data?.results || [];

        if (!videos.length) throw new Error('لا توجد فيديوهات غابيمارو');

        const randomVideo = videos[Math.floor(Math.random() * videos.length)];

        // ✅ تحميل الفيديو بأعلى جودة متاحة
        const dlRes = await axios.get(`${API_URL}/api/pinterest/public`, {
            params: {
                api_key: 'free_key',
                url: randomVideo.url,
                type: 'video',
                quality: '8k'
            },
            timeout: 300000,
            validateStatus: () => true
        });

        const dlData = dlRes.data;

        if (!dlData?.success || !dlData?.fileKey) {
            throw new Error('فشل تحميل فيديو غابيمارو');
        }

        // ✅ تنزيل الملف
        const fileRes = await axios.get(
            `${API_URL}/api/pinterest/download?file=${dlData.fileKey}`,
            {
                responseType: 'arraybuffer',
                timeout: 300000,
                validateStatus: () => true
            }
        );

        const videoBuffer = Buffer.from(fileRes.data);

        if (!videoBuffer.length) {
            throw new Error('ملف فارغ');
        }

        // ✅ إرسال الفيديو بنفس الطريقة
        await conn.sendMessage(m.chat, {
            video: videoBuffer,
            ptv: true,
            caption: theme.build([
                { type: 'title', text: '🎬 فـيـديـو غـابـيـمـارو' },
                { type: 'divider' },
                { type: 'info', label: 'الـجـودة', value: '8K' },
                { type: 'info', label: 'الـمـطـور', value: '𝑮𝑨𝑩𝑰𝑴𝑨𝑹𝑼 🍷' }
            ]),
            contextInfo: {
                isForwarded: true,
                forwardingScore: 999,
                forwardedNewsletterMessageInfo: {
                    newsletterJid: randomChannel.jid,
                    newsletterName: randomChannel.name,
                    serverMessageId: '0'
                }
            }
        }, { quoted: m });

        await conn.sendMessage(m.chat, {
            react: { text: '✅', key: m.key }
        });

    } catch (e) {

        console.error("خطأ:", e);

        await conn.sendMessage(m.chat, {
            react: { text: '❌', key: m.key }
        });

        await conn.reply(
            m.chat,
            theme.build([
                { type: 'title', text: '❌ فـشـل الـتـحـمـيـل' },
                { type: 'subtitle', text: 'حدث خطأ أثناء جلب فيديو غابيمارو' },
                { type: 'divider' },
                { type: 'line', text: 'حاول مرة أخرى لاحقاً' }
            ]),
            m
        );
    }
};

handler.help = ['انمي'];
handler.tags = ['anime'];
handler.command = /^(تست|anime|انم)$/i;

export default handler;