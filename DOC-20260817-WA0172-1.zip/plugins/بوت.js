// plugins/bot.js
// ♡ Raiden Shogun - Plane of Euthymia - Bot Info 🔘

import { ButtonV2 } from '../core/NIXCODE.js'

let handler = async (m, { conn }) => {

    const imageUrl = 'https://i.ibb.co/FLQCCq2N/4e802e6300d1740335156658f94c12dd-1.jpg'

    await new ButtonV2(conn)
        .setBody(global.botName)
        .setFooter(global.watermark)
        .setThumbnail(imageUrl)
        .addButton('📂 الـقـائـمـة', '.اوامر')
        .addButton('👑 الـمـطـور', '.المطور')
        .send(m.chat)

}

handler.customPrefix = /^(\.)?(بوت|bot)$/i
handler.command = new RegExp()

export default handler