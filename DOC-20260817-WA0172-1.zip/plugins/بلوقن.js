// plugins/بلوقن.js
// ✧ 2B - YoRHa Unit No.2 Type B - إدارة البلوقنات 📦

import fs from "fs";
import path from "path";
import { downloadContentFromMessage } from "@whiskeysockets/baileys";
import { theme } from "../core/theme.js";

// ═══════════════════════════════════════════════════════
// ZIP بدون أي مكتبة خارجية
// ═══════════════════════════════════════════════════════

function crc32(buffer) {
    let crc = 0 ^ -1;

    for (let i = 0; i < buffer.length; i++) {
        crc ^= buffer[i];

        for (let j = 0; j < 8; j++) {
            crc = (crc >>> 1) ^ (0xEDB88320 & -(crc & 1));
        }
    }

    return (crc ^ -1) >>> 0;
}

function uint16(value) {
    const buffer = Buffer.alloc(2);
    buffer.writeUInt16LE(value, 0);
    return buffer;
}

function uint32(value) {
    const buffer = Buffer.alloc(4);
    buffer.writeUInt32LE(value >>> 0, 0);
    return buffer;
}

function createZip(fileName, fileBuffer) {
    const nameBuffer = Buffer.from(fileName, "utf8");
    const crc = crc32(fileBuffer);

    // Local File Header
    const localHeader = Buffer.concat([
        uint32(0x04034b50),
        uint16(20),
        uint16(0),
        uint16(0),
        uint16(0),
        uint16(0),
        uint32(crc),
        uint32(fileBuffer.length),
        uint32(fileBuffer.length),
        uint16(nameBuffer.length),
        uint16(0),
        nameBuffer
    ]);

    const fileData = Buffer.concat([
        localHeader,
        fileBuffer
    ]);

    // Central Directory Header
    const centralHeader = Buffer.concat([
        uint32(0x02014b50),
        uint16(20),
        uint16(20),
        uint16(0),
        uint16(0),
        uint16(0),
        uint16(0),
        uint32(crc),
        uint32(fileBuffer.length),
        uint32(fileBuffer.length),
        uint16(nameBuffer.length),
        uint16(0),
        uint16(0),
        uint16(0),
        uint16(0),
        uint32(0),
        uint32(0),
        nameBuffer
    ]);

    // End Of Central Directory
    const endRecord = Buffer.concat([
        uint32(0x06054b50),
        uint16(0),
        uint16(0),
        uint16(1),
        uint16(1),
        uint32(centralHeader.length),
        uint32(fileData.length),
        uint16(0)
    ]);

    return Buffer.concat([
        fileData,
        centralHeader,
        endRecord
    ]);
}

// ═══════════════════════════════════════════════════════
// Handler
// ═══════════════════════════════════════════════════════

let handler = async (m, { conn, args, usedPrefix }) => {

    // ═══════════════════════════════════════════════════
    // تفاعل
    // ═══════════════════════════════════════════════════

    const react = async (emoji) => {
        try {
            await conn.sendMessage(
                m.chat,
                {
                    react: {
                        text: emoji,
                        key: m.key
                    }
                }
            );
        } catch {}
    };

    // ═══════════════════════════════════════════════════
    // مجلد البلوقنات
    // ═══════════════════════════════════════════════════

    const pluginsDir = path.dirname(
        global.__filename(import.meta.url, true)
    );

    const currentFile = path.basename(
        global.__filename(import.meta.url, true)
    );

    // ═══════════════════════════════════════════════════
    // جلب البلوقنات
    // ═══════════════════════════════════════════════════

    const getPlugins = () => {
        try {
            return fs
                .readdirSync(pluginsDir)
                .filter(file =>
                    file.endsWith(".js") &&
                    file !== currentFile
                );
        } catch {
            return [];
        }
    };

    // ═══════════════════════════════════════════════════
    // البحث عن البلوقن
    // ═══════════════════════════════════════════════════

    const findPlugin = (name) => {

        let searchName = name
            .replace(/\.js$/i, "")
            .trim()
            .toLowerCase()
            .replace(/\s+/g, "-");

        if (!searchName) return null;

        const allFiles = getPlugins();

        // تطابق كامل
        let found = allFiles.find(
            file =>
                file.toLowerCase() ===
                `${searchName}.js`
        );

        if (found) return found;

        // تطابق - و _
        found = allFiles.find(
            file =>
                file
                    .replace(/-/g, "_")
                    .toLowerCase() ===
                `${searchName
                    .replace(/-/g, "_")
                    .toLowerCase()}.js`
        );

        if (found) return found;

        // بحث جزئي
        found = allFiles.find(
            file =>
                file
                    .replace(/\.js$/i, "")
                    .toLowerCase()
                    .includes(searchName)
        );

        if (found) return found;

        return null;
    };

    const action = (args[0] || "").toLowerCase();

    // ═══════════════════════════════════════════════════
    // 📄 عرض البلوقن كملف ZIP
    // ═══════════════════════════════════════════════════

    if (/^(عرض|show|get)$/i.test(action)) {

        const nameArg = args
            .slice(1)
            .join(" ")
            .trim();

        if (!nameArg) {

            await react("❌");

            return m.reply(
                theme.build([
                    {
                        type: "title",
                        text: "📦 عـرض بـلـوقـن - 2B"
                    },
                    {
                        type: "divider"
                    },
                    {
                        type: "info",
                        label: "📌 الاستخدام",
                        value:
                            `${usedPrefix}بلوقن عرض <اسم البلوقن>`
                    },
                    {
                        type: "info",
                        label: "📦 النتيجة",
                        value:
                            "سيتم إرسال البلوقن داخل ملف ZIP"
                    }
                ])
            );
        }

        const foundFile = findPlugin(nameArg);

        if (!foundFile) {

            await react("❌");

            return m.reply(
                theme.build([
                    {
                        type: "title",
                        text: "❌ 2B - خـطـأ"
                    },
                    {
                        type: "error",
                        text:
                            `البلوقن "${nameArg}" غير موجود`
                    },
                    {
                        type: "info",
                        label: "💡 مثال",
                        value:
                            `${usedPrefix}بلوقن لست`
                    }
                ])
            );
        }

        const filePath = path.join(
            pluginsDir,
            foundFile
        );

        if (!fs.existsSync(filePath)) {

            await react("❌");

            return m.reply(
                "❌ الملف غير موجود داخل مجلد البلوقنات."
            );
        }

        try {

            await react("📦");

            // قراءة الكود
            const fileBuffer =
                fs.readFileSync(filePath);

            const code =
                fileBuffer.toString("utf8");

            const fileSize =
                (fileBuffer.length / 1024)
                    .toFixed(2);

            const lineCount =
                code.split("\n").length;

            // إنشاء ZIP
            const zipBuffer =
                createZip(
                    foundFile,
                    fileBuffer
                );

            const zipName =
                foundFile
                    .replace(/\.js$/i, "") +
                ".zip";

            // إرسال الملف
            await conn.sendMessage(
                m.chat,
                {
                    document: zipBuffer,
                    fileName: zipName,
                    mimetype: "application/zip",
                    caption:
`╭━━━〔 📦 2B • PLUGIN 〕━━━╮
│
│ 📄 الملف : ${foundFile}
│ 📦 الحجم : ${fileSize} KB
│ 📝 الأسطر : ${lineCount}
│
│ 🗜️ تم ضغط البلوقن داخل ZIP
│
│ ✦ 2B - YoRHa Unit No.2
│
╰━━━━━━━━━━━━━━━━━━━━━━╯`
                },
                {
                    quoted: m
                }
            );

            await react("✅");

        } catch (error) {

            console.error(
                "[2B-PLUGIN-SHOW]",
                error
            );

            await react("❌");

            return m.reply(
`❌ فشل إرسال البلوقن.

📄 الملف: ${foundFile}

⚠️ الخطأ:
${error.message}`
            );
        }

        return;
    }

    // ═══════════════════════════════════════════════════
    // 📋 قائمة البلوقنات
    // ═══════════════════════════════════════════════════

    if (/^(لست|list)$/i.test(action)) {

        const plugins = getPlugins();

        if (!plugins.length) {

            await react("📦");

            return m.reply(
                theme.build([
                    {
                        type: "title",
                        text:
                            "📂 2B - لا يـوجـد بـلـوقـنـات"
                    }
                ])
            );
        }

        const lines = [
            theme.divider,
            "│",
            "│ 📦 *قـائـمـة الـبـلـوقـنـات - 2B*",
            "│"
        ];

        plugins.forEach((file, index) => {

            lines.push(
                `│ ${index + 1}. ${file.replace(".js", "")}`
            );

        });

        lines.push(
            "│",
            `│ 📊 المجموع: ${plugins.length} بلوقن`,
            theme.endDivider
        );

        await react("📦");

        return m.reply(
            lines.join("\n")
        );
    }

    // ═══════════════════════════════════════════════════
    // 🗑️ حذف البلوقن
    // ═══════════════════════════════════════════════════

    if (/^(حذف|delete|del|remove)$/i.test(action)) {

        const nameArg = args
            .slice(1)
            .join(" ")
            .trim();

        if (!nameArg) {

            await react("❌");

            return m.reply(
                theme.build([
                    {
                        type: "title",
                        text: "🗑️ حـذف بـلـوقـن - 2B"
                    },
                    {
                        type: "info",
                        label: "📌 الاستخدام",
                        value:
                            `${usedPrefix}بلوقن حذف <اسم>`
                    }
                ])
            );
        }

        const foundFile =
            findPlugin(nameArg);

        if (!foundFile) {

            await react("❌");

            return m.reply(
                theme.build([
                    {
                        type: "title",
                        text: "❌ 2B - خـطـأ"
                    },
                    {
                        type: "error",
                        text:
                            `البلوقن "${nameArg}" غير موجود`
                    }
                ])
            );
        }

        const filePath =
            path.join(
                pluginsDir,
                foundFile
            );

        try {

            const code =
                fs.readFileSync(
                    filePath,
                    "utf8"
                );

            const fileSize =
                (
                    Buffer.byteLength(code, "utf8") /
                    1024
                ).toFixed(2);

            const lineCount =
                code.split("\n").length;

            fs.unlinkSync(filePath);

            if (global.plugins?.[foundFile]) {
                delete global.plugins[foundFile];
            }

            await react("🗑️");

            return m.reply(
                theme.build([
                    {
                        type: "title",
                        text:
                            "🗑️ 2B - تـم الـحـذف"
                    },
                    {
                        type: "divider"
                    },
                    {
                        type: "info",
                        label: "📄 الملف",
                        value: foundFile
                    },
                    {
                        type: "info",
                        label: "📦 الحجم",
                        value:
                            `${fileSize} KB`
                    },
                    {
                        type: "info",
                        label: "📝 الأسطر",
                        value:
                            `${lineCount} سطر`
                    }
                ])
            );

        } catch (error) {

            await react("❌");

            return m.reply(
                `❌ فشل حذف البلوقن:\n${error.message}`
            );
        }
    }

    // ═══════════════════════════════════════════════════
    // ➕ إضافة / تعديل بلوقن
    // ═══════════════════════════════════════════════════

    if (/^(اضف|اضافه|اضافة|add)$/i.test(action)) {

        const quoted = m.quoted;

        if (!quoted) {

            await react("❌");

            return m.reply(
                theme.build([
                    {
                        type: "title",
                        text: "➕ إضـافـة بـلـوقـن - 2B"
                    },
                    {
                        type: "error",
                        text:
                            "رد على كود أو ملف البلوقن"
                    }
                ])
            );
        }

        let code = "";
        let fileName = "";

        // ═══════════════════════════════════════════
        // استخراج document
        // ═══════════════════════════════════════════

        const docMsg =
            quoted.message?.documentMessage ||
            quoted.message
                ?.documentWithCaptionMessage
                ?.message
                ?.documentMessage ||
            null;

        // ═══════════════════════════════════════════
        // إذا كان المرفق ملف
        // ═══════════════════════════════════════════

        if (docMsg) {

            let buffer;

            try {

                buffer =
                    await quoted.download();

            } catch {

                try {

                    const stream =
                        await downloadContentFromMessage(
                            docMsg,
                            "document"
                        );

                    const chunks = [];

                    for await (
                        const chunk of stream
                    ) {
                        chunks.push(chunk);
                    }

                    buffer =
                        Buffer.concat(chunks);

                } catch (error) {

                    await react("❌");

                    return m.reply(
                        `❌ فشل تحميل الملف:\n${error.message}`
                    );
                }
            }

            const originalName =
                docMsg.fileName ||
                `plugin_${Date.now()}`;

            const baseName =
                originalName
                    .replace(/\.js$/i, "")
                    .replace(/\.zip$/i, "");

            fileName =
                `${baseName}.js`;

            code =
                buffer.toString("utf8");

        } else {

            // ═══════════════════════════════════════════
            // إذا كان الكود داخل رسالة
            // ═══════════════════════════════════════════

            code =
                quoted.text ||
                quoted.body ||
                "";

            if (!code.trim()) {

                await react("❌");

                return m.reply(
                    theme.build([
                        {
                            type: "title",
                            text: "❌ 2B - خـطـأ"
                        },
                        {
                            type: "error",
                            text:
                                "الرسالة لا تحتوي على كود"
                        }
                    ])
                );
            }

            let extractedName = null;

            // handler.command = /.../
            const cmdMatch1 =
                code.match(
                    /handler\.command\s*=\s*\/\^?\(?([^\/)|\\s]+)/
                );

            if (cmdMatch1) {
                extractedName =
                    cmdMatch1[1].trim();
            }

            // handler.command = ['name']
            if (!extractedName) {

                const cmdMatch2 =
                    code.match(
                        /handler\.command\s*=\s*\[['"`]([^'"`]+)['"`]/
                    );

                if (cmdMatch2) {
                    extractedName =
                        cmdMatch2[1].trim();
                }
            }

            // // plugins/name.js
            if (!extractedName) {

                const fileMatch =
                    code.match(
                        /\/\/\s*(?:plugins|commands)\/([a-zA-Z0-9_\u0600-\u06FF-]+)\.js/
                    );

                if (fileMatch) {
                    extractedName =
                        fileMatch[1].trim();
                }
            }

            // اسم افتراضي
            if (!extractedName) {

                extractedName =
                    `plugin_${Date.now().toString(36)}`;
            }

            fileName =
                `${extractedName}.js`;
        }

        // ═══════════════════════════════════════════
        // حفظ الملف
        // ═══════════════════════════════════════════

        const savePath =
            path.join(
                pluginsDir,
                fileName
            );

        const isEdit =
            fs.existsSync(savePath);

        try {

            fs.writeFileSync(
                savePath,
                code,
                "utf8"
            );

        } catch (error) {

            await react("❌");

            return m.reply(
                `❌ فشل حفظ البلوقن:\n${error.message}`
            );
        }

        const fileSize =
            (
                Buffer.byteLength(code, "utf8") /
                1024
            ).toFixed(2);

        const lineCount =
            code.split("\n").length;

        await react("✅");

        return m.reply(
            theme.build([
                {
                    type: "title",
                    text: isEdit
                        ? "✏️ 2B - تـم الـتـعـديـل"
                        : "✅ 2B - تـم الإضـافـة"
                },
                {
                    type: "divider"
                },
                {
                    type: "info",
                    label: "📄 الملف",
                    value: fileName
                },
                {
                    type: "info",
                    label: "📦 الحجم",
                    value:
                        `${fileSize} KB`
                },
                {
                    type: "info",
                    label: "📝 الأسطر",
                    value:
                        `${lineCount} سطر`
                }
            ])
        );
    }

    // ═══════════════════════════════════════════════════
    // 📦 القائمة الرئيسية
    // ═══════════════════════════════════════════════════

    await react("📦");

    return m.reply(
        theme.build([
            {
                type: "title",
                text:
                    "📦 2B - إدارة الـبـلـوقـنـات"
            },
            {
                type: "divider"
            },
            {
                type: "info",
                label: "📋 لست",
                value:
                    `${usedPrefix}بلوقن لست`
            },
            {
                type: "info",
                label: "📄 عرض",
                value:
                    `${usedPrefix}بلوقن عرض <اسم>`
            },
            {
                type: "info",
                label: "➕ اضف",
                value:
                    `${usedPrefix}بلوقن اضف`
            },
            {
                type: "info",
                label: "🗑️ حذف",
                value:
                    `${usedPrefix}بلوقن حذف <اسم>`
            }
        ])
    );
};

// ═══════════════════════════════════════════════════════
// إعدادات الأمر
// ═══════════════════════════════════════════════════════

handler.help = [
    "بلوقن"
];

handler.tags = [
    "owner"
];

handler.command =
    /^(بلوقن|plugin|plugins)$/i;

handler.owner = true;

export default handler;