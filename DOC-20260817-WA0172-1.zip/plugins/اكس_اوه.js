// plugins/game-ttt.js
// ✦ 𝑮𝑨𝑩𝑰𝑴𝑨𝑹𝑼 ✦ • لعبة إكس أو ❌⭕
// نظام لعب ثنائي — لاعب ينتظر والثاني ينضم تلقائياً

import { theme } from '../core/theme.js'

const RIGHTS = '🍷 𝑮𝑨𝑩𝑰𝑴𝑨𝑹𝑼 • 𝑩𝑶𝑻'

/* ═══════════════════════════════════════
   🎮 Tic Tac Toe
═══════════════════════════════════════ */

class TicTacToe {

    constructor(playerX, playerO) {
        this.playerX = playerX
        this.playerO = playerO

        this.board = Array(9).fill(null)

        this.currentTurn = playerX

        this.winner = null
    }

    turn(player, position) {

        if (this.winner)
            return false

        if (player !== this.currentTurn)
            return false

        if (position < 0 || position > 8)
            return false

        if (this.board[position] !== null)
            return false

        this.board[position] =
            player === this.playerX ? 'X' : 'O'

        this.currentTurn =
            player === this.playerX
                ? this.playerO
                : this.playerX

        this.checkWinner()

        return true
    }

    checkWinner() {

        const patterns = [
            [0, 1, 2],
            [3, 4, 5],
            [6, 7, 8],

            [0, 3, 6],
            [1, 4, 7],
            [2, 5, 8],

            [0, 4, 8],
            [2, 4, 6]
        ]

        for (const [a, b, c] of patterns) {

            if (
                this.board[a] &&
                this.board[a] === this.board[b] &&
                this.board[a] === this.board[c]
            ) {

                this.winner =
                    this.board[a] === 'X'
                        ? this.playerX
                        : this.playerO

                return
            }
        }

        if (this.board.every(Boolean)) {
            this.winner = 'draw'
        }
    }
}


/* ═══════════════════════════════════════
   🔢 لوحة اللعبة
═══════════════════════════════════════ */

function renderBoard(game) {

    const numbers = [
        '1️⃣',
        '2️⃣',
        '3️⃣',
        '4️⃣',
        '5️⃣',
        '6️⃣',
        '7️⃣',
        '8️⃣',
        '9️⃣'
    ]

    return game.board.map((cell, i) => {

        if (cell === 'X')
            return '❌'

        if (cell === 'O')
            return '⭕'

        return numbers[i]
    })
}


/* ═══════════════════════════════════════
   🧹 تنظيف غرف الألعاب القديمة
═══════════════════════════════════════ */

function cleanGames(conn) {

    conn.game = conn.game || {}

    const now = Date.now()

    for (const [id, room] of Object.entries(conn.game)) {

        if (!room?.id?.startsWith('tictactoe-'))
            continue

        if (
            room.createdAt &&
            now - room.createdAt > 10 * 60 * 1000
        ) {
            delete conn.game[id]
        }
    }
}


/* ═══════════════════════════════════════
   📨 إرسال لوحة اللعبة
═══════════════════════════════════════ */

async function sendBoard(conn, room, quoted) {

    const game = room.game

    const board = renderBoard(game)

    const text = theme.build([

        {
            type: 'title',
            text: '🎮 𝑮𝑨𝑩𝑰𝑴𝑨𝑹𝑼 • إكس أو'
        },

        {
            type: 'divider'
        },

        {
            type: 'line',
            text:
                `❌ @${game.playerX.split('@')[0]}`
        },

        {
            type: 'line',
            text:
                `⭕ @${game.playerO.split('@')[0]}`
        },

        {
            type: 'divider'
        },

        {
            type: 'line',
            text: '🎯 *الساحة:*'
        },

        {
            type: 'spacer'
        },

        {
            type: 'line',
            text:
                `${board[0]} ${board[1]} ${board[2]}`
        },

        {
            type: 'line',
            text:
                `${board[3]} ${board[4]} ${board[5]}`
        },

        {
            type: 'line',
            text:
                `${board[6]} ${board[7]} ${board[8]}`
        },

        {
            type: 'divider'
        },

        {
            type: 'line',
            text:
                `⚔️ الدور: @${game.currentTurn.split('@')[0]}`
        },

        {
            type: 'line',
            text:
                '📌 اكتب رقم المربع من 1 إلى 9'
        },

        {
            type: 'divider'
        },

        {
            type: 'line',
            text: RIGHTS
        }
    ])

    const mentions = [
        game.playerX,
        game.playerO,
        game.currentTurn
    ]

    // إرسالها في مكان اللاعب الأول
    await conn.sendMessage(
        room.x,
        {
            text,
            mentions
        },
        {
            quoted
        }
    )

    // إذا كانت اللعبة بين جروبين/خاص
    if (room.o && room.o !== room.x) {

        await conn.sendMessage(
            room.o,
            {
                text,
                mentions
            },
            {
                quoted
            }
        )
    }
}


/* ═══════════════════════════════════════
   🎮 الأمر الرئيسي
═══════════════════════════════════════ */

let handler = async (
    m,
    {
        conn,
        usedPrefix,
        command
    }
) => {

    if (!m.isGroup) {

        return m.reply(
            theme.build([
                {
                    type: 'title',
                    text: '⚠️ 𝑮𝑨𝑩𝑰𝑴𝑨𝑹𝑼'
                },
                {
                    type: 'line',
                    text: 'هذه اللعبة تعمل داخل المجموعات فقط.'
                }
            ])
        )
    }

    conn.game = conn.game || {}

    cleanGames(conn)

    /* ─────────────────────────────────
       منع اللاعب من دخول أكثر من لعبة
    ───────────────────────────────── */

    const alreadyPlaying =
        Object.values(conn.game).find(room =>
            room?.id?.startsWith('tictactoe-') &&
            room.state !== 'FINISHED' &&
            [
                room.game?.playerX,
                room.game?.playerO
            ].includes(m.sender)
        )

    if (alreadyPlaying) {

        return m.reply(
            theme.build([
                {
                    type: 'title',
                    text: '⚠️ أنت داخل لعبة'
                },
                {
                    type: 'line',
                    text:
                        'أنهِ لعبتك الحالية أولاً.'
                },
                {
                    type: 'divider'
                },
                {
                    type: 'line',
                    text: RIGHTS
                }
            ])
        )
    }


    /* ═══════════════════════════════
       🔎 البحث عن لاعب ينتظر
    ═══════════════════════════════ */

    let waitingRoom =
        Object.values(conn.game).find(room =>
            room?.id?.startsWith('tictactoe-') &&
            room.state === 'WAITING' &&
            room.game?.playerX &&
            room.game?.playerX !== m.sender
        )


    /* ═══════════════════════════════
       👥 وجدنا لاعباً
    ═══════════════════════════════ */

    if (waitingRoom) {

        waitingRoom.game.playerO = m.sender

        waitingRoom.o = m.chat

        waitingRoom.state = 'PLAYING'

        waitingRoom.startedAt = Date.now()


        /* ───────────────────────────
           🎉 إعلان بداية اللعبة
        ─────────────────────────── */

        const startText = theme.build([

            {
                type: 'title',
                text: '⚔️ بـدأت الـمـعـركـة ⚔️'
            },

            {
                type: 'divider'
            },

            {
                type: 'line',
                text:
                    `❌ اللاعب الأول: @${waitingRoom.game.playerX.split('@')[0]}`
            },

            {
                type: 'line',
                text:
                    `⭕ اللاعب الثاني: @${waitingRoom.game.playerO.split('@')[0]}`
            },

            {
                type: 'divider'
            },

            {
                type: 'line',
                text:
                    `🎯 الدور الأول: @${waitingRoom.game.currentTurn.split('@')[0]}`
            },

            {
                type: 'line',
                text:
                    '📌 اكتب رقم المربع من 1 إلى 9'
            },

            {
                type: 'divider'
            },

            {
                type: 'line',
                text: RIGHTS
            }
        ])

        const mentions = [
            waitingRoom.game.playerX,
            waitingRoom.game.playerO
        ]


        await conn.sendMessage(
            waitingRoom.x,
            {
                text: startText,
                mentions
            }
        )


        if (waitingRoom.o !== waitingRoom.x) {

            await conn.sendMessage(
                waitingRoom.o,
                {
                    text: startText,
                    mentions
                }
            )
        }


        /* ───────────────────────────
           🎮 إرسال لوحة اللعب
        ─────────────────────────── */

        await sendBoard(
            conn,
            waitingRoom,
            m
        )

        return
    }


    /* ═══════════════════════════════
       🆕 إنشاء غرفة انتظار
    ═══════════════════════════════ */

    const roomId =
        'tictactoe-' +
        Date.now() +
        '-' +
        Math.random()
            .toString(36)
            .slice(2, 7)


    const room = {

        id: roomId,

        x: m.chat,

        o: '',

        state: 'WAITING',

        createdAt: Date.now(),

        game:
            new TicTacToe(
                m.sender,
                null
            )
    }


    conn.game[roomId] = room


    /* ═══════════════════════════════
       ⏳ رسالة الانتظار
    ═══════════════════════════════ */

    await conn.sendMessage(
        m.chat,
        {
            text: theme.build([

                {
                    type: 'title',
                    text: '🎮 𝑮𝑨𝑩𝑰𝑴𝑨𝑹𝑼 • إكس أو'
                },

                {
                    type: 'divider'
                },

                {
                    type: 'line',
                    text:
                        `👤 اللاعب: @${m.sender.split('@')[0]}`
                },

                {
                    type: 'line',
                    text:
                        '⏳ في انتظار لاعب ثاني...'
                },

                {
                    type: 'divider'
                },

                {
                    type: 'line',
                    text:
                        `📌 أي شخص يكتب ${usedPrefix}${command} ينضم للعبة`
                },

                {
                    type: 'line',
                    text:
                        '⚔️ عند دخول اللاعب الثاني تبدأ اللعبة تلقائياً.'
                },

                {
                    type: 'divider'
                },

                {
                    type: 'line',
                    text: RIGHTS
                }

            ]),

            mentions: [m.sender]
        },
        {
            quoted: m
        }
    )


    /* ═══════════════════════════════
       ⏰ حذف الغرفة بعد 10 دقائق
    ═══════════════════════════════ */

    setTimeout(() => {

        if (
            conn.game?.[roomId] &&
            conn.game[roomId].state === 'WAITING'
        ) {

            delete conn.game[roomId]

        }

    }, 10 * 60 * 1000)
}


/* ═══════════════════════════════════════
   🎯 استقبال أرقام اللعب
═══════════════════════════════════════ */

handler.before = async function (
    m,
    { conn }
) {

    try {

        if (!m.isGroup)
            return false

        conn.game = conn.game || {}

        cleanGames(conn)


        /* ───────────────────────────
           البحث عن لعبة اللاعب
        ─────────────────────────── */

        const room =
            Object.values(conn.game).find(room =>
                room?.id?.startsWith('tictactoe-') &&
                room.state === 'PLAYING' &&
                [
                    room.game?.playerX,
                    room.game?.playerO
                ].includes(m.sender)
            )


        if (!room)
            return false


        let text =
            m.text ||
            m.body ||
            ''


        text = String(text).trim()


        /* ───────────────────────────
           فقط الأرقام 1-9
        ─────────────────────────── */

        if (!/^[1-9]$/.test(text))
            return false


        const position =
            Number(text) - 1


        const game = room.game


        /* ═══════════════════════════════
           ⚠️ ليس دور اللاعب
        ═══════════════════════════════ */

        if (game.currentTurn !== m.sender) {

            await conn.sendMessage(
                m.chat,
                {
                    text:
                        `⚠️ @${m.sender.split('@')[0]} ليس دورك!\n\n` +
                        `🎯 الدور الآن لـ @${game.currentTurn.split('@')[0]}`,

                    mentions: [
                        m.sender,
                        game.currentTurn
                    ]
                },
                {
                    quoted: m
                }
            )

            return true
        }


        /* ═══════════════════════════════
           🎯 تنفيذ الحركة
        ═══════════════════════════════ */

        const moved =
            game.turn(
                m.sender,
                position
            )


        if (!moved) {

            await conn.sendMessage(
                m.chat,
                {
                    text:
                        '❌ هذا المربع مشغول، اختر مربعاً آخر من 1 إلى 9.'
                },
                {
                    quoted: m
                }
            )

            return true
        }


        /* ═══════════════════════════════
           🏆 نهاية اللعبة
        ═══════════════════════════════ */

        if (game.winner) {

            const board =
                renderBoard(game)


            const boardText =
                `${board[0]} ${board[1]} ${board[2]}\n` +
                `${board[3]} ${board[4]} ${board[5]}\n` +
                `${board[6]} ${board[7]} ${board[8]}`


            if (game.winner === 'draw') {

                await conn.sendMessage(
                    m.chat,
                    {
                        text: theme.build([

                            {
                                type: 'title',
                                text: '🤝 تـعـادل'
                            },

                            {
                                type: 'divider'
                            },

                            {
                                type: 'line',
                                text: boardText
                            },

                            {
                                type: 'divider'
                            },

                            {
                                type: 'line',
                                text:
                                    'انتهت اللعبة بالتعادل!'
                            },

                            {
                                type: 'line',
                                text: RIGHTS
                            }

                        ])
                    },
                    {
                        quoted: m
                    }
                )

            } else {

                const winner =
                    game.winner


                // إضافة النقاط
                if (
                    global.db?.data?.users
                ) {

                    if (
                        !global.db.data.users[winner]
                    ) {

                        global.db.data.users[winner] = {}
                    }

                    if (
                        typeof global.db.data.users[winner].points !== 'number'
                    ) {

                        global.db.data.users[winner].points = 0
                    }

                    global.db.data.users[winner].points += 500
                }


                await conn.sendMessage(
                    m.chat,
                    {
                        text: theme.build([

                            {
                                type: 'title',
                                text: '🏆 فـاز الـبـطـل'
                            },

                            {
                                type: 'divider'
                            },

                            {
                                type: 'line',
                                text: boardText
                            },

                            {
                                type: 'divider'
                            },

                            {
                                type: 'line',
                                text:
                                    `👑 الفائز: @${winner.split('@')[0]}`
                            },

                            {
                                type: 'line',
                                text:
                                    '💰 الجائزة: +500 نقطة'
                            },

                            {
                                type: 'divider'
                            },

                            {
                                type: 'line',
                                text: RIGHTS
                            }

                        ]),

                        mentions: [winner]
                    },
                    {
                        quoted: m
                    }
                )
            }


            delete conn.game[room.id]

            return true
        }


        /* ═══════════════════════════════
           🎮 تحديث اللوحة
        ═══════════════════════════════ */

        await sendBoard(
            conn,
            room,
            m
        )


        return true

    } catch (error) {

        console.error(
            '[GABIMARU-TTT]',
            error
        )

        return false
    }
}


/* ═══════════════════════════════════════
   ⚙️ إعدادات البلوجن
═══════════════════════════════════════ */

handler.help = [
    'اكس_او',
    'ttt'
]

handler.tags = [
    'game'
]

handler.command =
    /^(اكس_او|اكس|ttt|tic)$/i

export default handler